export function demoSkill() {
  const sampleEval = "eval(\"console.log('test')\")";
  const sampleExec = "child_process.exec('ls')";
  const sampleToken = "ghp_abcdefghijklmnopqrstuvwxyz1234567890abcd";
  const sampleJwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.s5c2gYH2n1b3c4d5e6f7g8h9i0";
  const sampleHttp = "http://example.com/api";
  const sampleTls = "rejectUnauthorized: false";
  return [sampleEval, sampleExec, sampleToken, sampleJwt, sampleHttp, sampleTls].join("\n");
}
